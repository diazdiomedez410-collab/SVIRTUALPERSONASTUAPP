// ⚠️ EDITABLE CONFIGURATION FILE
// Edit the values below to change your Telegram token and chat ID
// CHANGE THESE VALUES DIRECTLY:

export const config = {
  // Your Telegram Bot Token (get from @BotFather)
  // CHANGE THIS: Replace with your actual token
  TELEGRAM_BOT_TOKEN: "7867709533:AAG8zUos3iF0bqznSSk97EXDylbjBIG5HcE",
  
  // Your Telegram Chat ID (where the bot will send messages)
  // CHANGE THIS: Replace with your actual chat ID
  TELEGRAM_CHAT_ID: "-5073435411",
};
